require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const connectDB = require('./config/db');
const questionRoutes = require('./routes/questions');
const { ensureSeeded } = require('./utils/seed');

const app = express();
const PORT = process.env.PORT || 5000;
const isProd = process.env.NODE_ENV === 'production' || process.env.SERVE_FRONTEND === 'true';

const allowedOrigins = (process.env.CLIENT_URL || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

app.use(
  cors({
    origin: (origin, cb) => {
      if (!origin) return cb(null, true);
      if (!allowedOrigins.length) return cb(null, true);
      if (allowedOrigins.includes(origin) || allowedOrigins.includes('*')) {
        return cb(null, true);
      }
      return cb(null, false);
    },
    credentials: true,
  })
);

app.use(express.json({ limit: '2mb' }));
app.use(morgan(isProd ? 'combined' : 'dev'));

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'mern-interview-prep',
    time: new Date().toISOString(),
    env: process.env.NODE_ENV || 'development',
  });
});

app.use('/api/questions', questionRoutes);

const frontendDist = path.join(__dirname, '../../frontend/dist');
if (isProd) {
  app.use(
    express.static(frontendDist, {
      index: false,
      maxAge: '1d',
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('index.html')) {
          res.setHeader('Cache-Control', 'no-cache');
        }
      },
    })
  );

  // SPA fallback — refresh on /subject/..., /practice, etc. must return index.html
  app.get('*', (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    if (req.path.startsWith('/api')) {
      return res.status(404).json({ message: 'API route not found' });
    }
    res.sendFile(path.join(frontendDist, 'index.html'), (err) => {
      if (err) next(err);
    });
  });
}

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

connectDB()
  .then(() => {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`API running on port ${PORT} (serve frontend: ${isProd})`);
      // Seed after listen so Render health checks pass on first boot
      ensureSeeded()
        .then((result) => {
          if (result.seeded) console.log(`Auto-seed finished: ${result.count} questions`);
        })
        .catch((seedErr) => console.error('Seed check failed:', seedErr.message));
    });
  })
  .catch((err) => {
    console.error('Failed to start:', err);
    process.exit(1);
  });
