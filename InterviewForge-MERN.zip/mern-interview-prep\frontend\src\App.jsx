import { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './components/Home';
import SubjectPage from './components/SubjectPage';
import Practice from './components/Practice';
import Bookmarks from './components/Bookmarks';
import AddQuestion from './components/AddQuestion';
import NotFound from './components/NotFound';
import { api } from './api';

export default function App() {
  const [subjects, setSubjects] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([api.getSubjects(), api.getStats()])
      .then(([subs, st]) => {
        setSubjects(subs);
        setStats(st);
        setError('');
      })
      .catch((err) => {
        console.error(err);
        setError(err.message || 'Could not reach the API');
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <BrowserRouter>
      <Layout>
        {error && (
          <div className="mb-6 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
            {error}. Check that the API is running and <code className="font-mono">MONGO_URI</code> is
            set.
          </div>
        )}
        <Routes>
          <Route path="/" element={<Home subjects={subjects} stats={stats} loading={loading} />} />
          <Route path="/subject/:subject" element={<SubjectPage />} />
          <Route path="/practice" element={<Practice />} />
          <Route path="/bookmarks" element={<Bookmarks />} />
          <Route path="/add" element={<AddQuestion />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
