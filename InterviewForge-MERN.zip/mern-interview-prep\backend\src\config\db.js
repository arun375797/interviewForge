const mongoose = require('mongoose');

function normalizeMongoUri(uri) {
  // Ensure a database name exists in the path (Atlas URIs often omit it)
  try {
    if (/mongodb(\+srv)?:\/\//.test(uri) && /\/\/[^/]+\/(\?|$)/.test(uri)) {
      return uri.replace(/\/\/([^/]+)\/(\?|$)/, '//$1/mern_interview_prep$2');
    }
  } catch {
    /* keep original */
  }
  return uri;
}

const connectDB = async () => {
  const raw = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/mern_interview_prep';
  const uri = normalizeMongoUri(raw);
  mongoose.set('strictQuery', true);
  await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 15000,
  });
  console.log('MongoDB connected');
};

module.exports = connectDB;
