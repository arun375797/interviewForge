const API_BASE = (import.meta.env.VITE_API_URL || '/api').replace(/\/$/, '');

async function request(path, options = {}) {
  const url = `${API_BASE}${path.startsWith('/') ? path : `/${path}`}`;
  const res = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || `Request failed (${res.status})`);
  return data;
}

export const api = {
  getSubjects: () => request('/questions/subjects'),
  getTopics: (subject) => request(`/questions/subjects/${subject}/topics`),
  getStats: () => request('/questions/stats'),
  getRandom: (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return request(`/questions/random${q ? `?${q}` : ''}`);
  },
  getQuestions: (params = {}) => {
    const q = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== undefined && v !== '' && v !== null)
    ).toString();
    return request(`/questions?${q}`);
  },
  getQuestion: (id) => request(`/questions/${id}`),
  createQuestion: (body) =>
    request('/questions', { method: 'POST', body: JSON.stringify(body) }),
  updateQuestion: (id, body) =>
    request(`/questions/${id}`, { method: 'PUT', body: JSON.stringify(body) }),
  deleteQuestion: (id) => request(`/questions/${id}`, { method: 'DELETE' }),
  toggleBookmark: (id) => request(`/questions/${id}/bookmark`, { method: 'PATCH' }),
  toggleMastered: (id) => request(`/questions/${id}/mastered`, { method: 'PATCH' }),
};

export const SUBJECT_META = {
  javascript: {
    label: 'JavaScript',
    short: 'JS',
    accent: '#CA8A04',
    blurb: 'Language fundamentals, async, DOM & patterns',
  },
  react: {
    label: 'React',
    short: 'React',
    accent: '#0891B2',
    blurb: 'Components, hooks, Redux & performance',
  },
  nodejs: {
    label: 'Node.js',
    short: 'Node',
    accent: '#16A34A',
    blurb: 'Runtime, Express, APIs & scaling',
  },
  dsa: {
    label: 'DSA',
    short: 'DSA',
    accent: '#DB2777',
    blurb: 'Structures, algorithms & complexity',
  },
};
