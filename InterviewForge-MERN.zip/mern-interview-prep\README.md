# InterviewForge — MERN Interview Prep

A full-stack MERN app built from your four question banks (JS, React, Node.js, DSA) with topic-wise questions, interview-style answers, and full CRUD — no authentication.

## Local setup

```bash
# Backend
cd backend
cp .env.example .env   # set MONGO_URI (include a DB name in the path)
npm install
npm run seed           # optional if DB is empty — server also auto-seeds
npm run dev

# Frontend (new terminal)
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

## Deploy on Render (recommended: one Web Service)

This project is set up so **Express serves the React build**. That means:

- One Render URL for both UI and API
- **Refresh on `/subject/react`, `/practice`, etc. works** (SPA fallback)
- Frontend calls `/api/...` on the same origin (no CORS issues)

### 1. MongoDB Atlas

1. Create a free cluster
2. Database Access → user + password
3. Network Access → allow `0.0.0.0/0` (or Render IPs)
4. Connect → Drivers → copy URI and **include a database name**:

```
mongodb+srv://USER:PASSWORD@cluster0.xxxxx.mongodb.net/mern_interview_prep?retryWrites=true&w=majority
```

### 2. Push this repo to GitHub

Make sure `.env` is **not** committed (it is in `.gitignore`).

### 3. Create a Web Service on Render

| Setting | Value |
|--------|--------|
| Root Directory | `mern-interview-prep` (if repo root is parent folder) **or** leave blank if this folder is the repo root |
| Runtime | Node |
| Build Command | `npm run build` |
| Start Command | `npm start` |
| Health Check Path | `/api/health` |

**Environment variables:**

| Key | Value |
|-----|--------|
| `NODE_ENV` | `production` |
| `SERVE_FRONTEND` | `true` |
| `MONGO_URI` | your Atlas URI (with DB name) |
| `CLIENT_URL` | *(optional)* leave empty when UI is served from the same service |

On first boot, if the database is empty, the server **auto-seeds** ~7,135 questions (may take 1–2 minutes). Health check still passes because the server listens first.

### 4. Optional: Blueprint

`render.yaml` is included — you can use **Blueprint** deploy from the Render dashboard and set `MONGO_URI` when prompted.

### Two-service option (Static Site + API)

If you prefer separate services:

**API Web Service**

- Root: `backend` (or `mern-interview-prep/backend`)
- Build: `npm install`
- Start: `npm start`
- Env: `NODE_ENV=production`, `MONGO_URI=...`, `CLIENT_URL=https://your-frontend.onrender.com`
- Do **not** set `SERVE_FRONTEND=true`

**Static Site**

- Root: `frontend`
- Build: `npm install && npm run build`
- Publish: `dist`
- Env: `VITE_API_URL=https://your-api.onrender.com/api`
- **Redirects / Rewrites:** add a rewrite rule so all routes serve `index.html` (required for refresh):

  - Source: `/*`
  - Destination: `/index.html`
  - Action: Rewrite

## Scripts

| Script | What it does |
|--------|----------------|
| `npm run build` | Install + build frontend, install backend deps |
| `npm start` | Start Express (serves API + `frontend/dist` in production) |
| `npm run seed` | Force re-seed (clears and reloads all questions) |

## Notes

- Never commit real Mongo credentials. Rotate the password if it was ever pushed to git.
- Free Render services spin down when idle; the first request after sleep can be slow.
- Auto-seed runs only when the questions collection is empty.
